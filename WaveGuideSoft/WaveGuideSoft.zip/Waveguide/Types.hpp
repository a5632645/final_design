#pragma once
#include <cstdint>

struct StereoSample {
    int16_t left;
    int16_t right;
};
